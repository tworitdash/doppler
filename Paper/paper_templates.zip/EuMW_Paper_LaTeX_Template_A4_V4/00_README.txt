
1) EuMW_Paper_LaTeX_Template_A4_V4.pdf
   This PDF contains format instructions for EuMW papers. 
   It is also the resulting PDF created from the source file 
   EuMW_Paper_LaTeX_Template_A4_V4.tex.

2) EuMW_Paper_LaTeX_Template_A4_V4.tex
   Authors should write their papers by editing this
   source file and adding their own text.

